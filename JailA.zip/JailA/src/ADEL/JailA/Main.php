<?php

namespace ADEL\JailA;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use pocketmine\world\Position;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\server\CommandEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\scheduler\Task;
use pocketmine\scheduler\TaskHandler;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;

class JailTimeTask extends Task {
    private $plugin;
    private $playerName;

    public function __construct(Main $plugin, string $playerName) {
        $this->plugin = $plugin;
        $this->playerName = $playerName;
    }

    public function onRun(): void {
        $this->plugin->updateJailTime($this->playerName);
    }
}

class JailReleaseTask extends Task {
    private $plugin;
    private $playerName;

    public function __construct(Main $plugin, string $playerName) {
        $this->plugin = $plugin;
        $this->playerName = $playerName;
    }

    public function onRun(): void {
        $this->plugin->unjailPlayer($this->playerName);
    }
}

class Main extends PluginBase implements Listener {

    private $jailPosition;
    private $jailedPlayers = [];
    private $timeTasks = [];
    private $releaseTasks = [];
    private $blockedCmds = [];
    private $maxDistance = 30;

    public function onEnable(): void {
        $this->saveDefaultConfig();
        $this->jailPosition = $this->getJailPosFromConfig();
        $this->blockedCmds = $this->getConfig()->get("blocked-commands", []);
        $this->loadJailedPlayers();
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        
        if ($this->getServer()->getPluginManager()->getPlugin("FormAPI") === null) {
            $this->getLogger()->error("FormAPI is required!");
            $this->getServer()->getPluginManager()->disablePlugin($this);
        }
    }

    private function getJailPosFromConfig(): ?Position {
        $pos = $this->getConfig()->get("jail-position", []);
        if (!empty($pos) && isset($pos["x"], $pos["y"], $pos["z"], $pos["level"])) {
            $world = $this->getServer()->getWorldManager()->getWorldByName($pos["level"]);
            if ($world !== null) {
                return new Position($pos["x"], $pos["y"], $pos["z"], $world);
            }
        }
        return null;
    }

    private function loadJailedPlayers(): void {
        $file = $this->getDataFolder() . "players.json";
        if (file_exists($file)) {
            $data = json_decode(file_get_contents($file), true);
            if (is_array($data)) {
                $this->jailedPlayers = $data;
            }
        }
    }

    private function saveJailedPlayers(): void {
        file_put_contents($this->getDataFolder() . "players.json", json_encode($this->jailedPlayers));
    }

    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args): bool {
        switch (strtolower($cmd->getName())) {
            case "jail":
                return $this->jailCommand($sender, $args);
            case "unjail":
                return $this->unjailCommand($sender, $args);
            case "setjail":
                return $this->setJailCommand($sender);
            case "jaillist":
                return $this->jailListCommand($sender);
            case "jailstatus":
                return $this->jailStatusCommand($sender, $args);
            default:
                return false;
        }
    }

    private function jailCommand(CommandSender $sender, array $args): bool {
        if (!$sender instanceof Player && count($args) < 1) {
            $sender->sendMessage(TextFormat::RED . "Usage: /jail <player> [duration]");
            return true;
        }

        if ($sender instanceof Player && count($args) < 1) {
            $this->showPlayerList($sender);
            return true;
        }

        $target = $this->getServer()->getPlayerByPrefix($args[0]);
        if (!$target instanceof Player) {
            $sender->sendMessage(TextFormat::RED . "Player not found or offline!");
            return true;
        }

        $duration = isset($args[1]) ? (int)$args[1] : 0;
        $this->jailPlayer($target, $duration);
        $sender->sendMessage(TextFormat::GREEN . "Jailed {$target->getName()} for " . ($duration > 0 ? "$duration seconds" : "unlimited time"));
        return true;
    }

    private function showPlayerList(Player $staff): void {
        $form = new SimpleForm(function(Player $staff, ?int $data) {
            if ($data === null) return;
            
            $players = array_values(array_filter($this->getServer()->getOnlinePlayers(), function($p) use ($staff) {
                return $p->getName() !== $staff->getName();
            }));
            
            if (isset($players[$data])) {
                $this->showJailTimeForm($staff, $players[$data]);
            }
        });

        $form->setTitle("Select Player");
        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            if ($player->getName() !== $staff->getName()) {
                $form->addButton($player->getName());
            }
        }
        $staff->sendForm($form);
    }

    private function showJailTimeForm(Player $staff, Player $target): void {
        $form = new CustomForm(function(Player $staff, ?array $data) use ($target) {
            if ($data === null) return;
            
            $time = (int)$data[1];
            $this->jailPlayer($target, $time);
            $staff->sendMessage(TextFormat::GREEN . "Jailed {$target->getName()} for {$time} seconds");
        });

        $form->setTitle("Jail {$target->getName()}");
        $form->addLabel("Jail duration (seconds, 0 for unlimited)");
        $form->addInput("Duration", "60");
        $staff->sendForm($form);
    }

    private function jailPlayer(Player $player, int $duration): void {
        $name = $player->getName();
        
        $this->jailedPlayers[$name] = [
            "pos" => [
                "x" => $player->getPosition()->getX(),
                "y" => $player->getPosition()->getY(),
                "z" => $player->getPosition()->getZ(),
                "world" => $player->getWorld()->getFolderName()
            ],
            "totalTime" => $duration,
            "remainingTime" => $duration,
            "isOnline" => true,
            "lastUpdate" => time()
        ];

        if ($this->jailPosition !== null) {
            $player->teleport($this->jailPosition);
            $player->sendTitle(
                $this->getConfig()->get("welcome-message", "§cYou have been jailed!"),
                $this->getConfig()->get("welcome-subtitle", "§7Follow the rules"),
                20, 60, 20
            );
            $player->sendMessage($this->getConfig()->get("jail-message", "§cYou have been sent to jail!"));
        }

        $this->startJailTime($name);
        $this->saveJailedPlayers();
    }

    private function startJailTime(string $playerName): void {
        if (isset($this->timeTasks[$playerName])) {
            $this->timeTasks[$playerName]->cancel();
        }

        $player = $this->getServer()->getPlayerExact($playerName);
        if ($player instanceof Player && $player->isOnline()) {
            $this->jailedPlayers[$playerName]["isOnline"] = true;
            $this->jailedPlayers[$playerName]["lastUpdate"] = time();
            
            $task = new JailTimeTask($this, $playerName);
            $this->timeTasks[$playerName] = $this->getScheduler()->scheduleRepeatingTask($task, 20);
            
            if ($this->jailedPlayers[$playerName]["totalTime"] > 0) {
                $this->scheduleRelease($playerName, $this->jailedPlayers[$playerName]["remainingTime"]);
            }
        }
    }

    public function updateJailTime(string $playerName): void {
        $player = $this->getServer()->getPlayerExact($playerName);
        
        if (!$player instanceof Player || !$player->isOnline()) {
            if (isset($this->timeTasks[$playerName])) {
                $this->timeTasks[$playerName]->cancel();
                unset($this->timeTasks[$playerName]);
            }
            return;
        }

        if (!isset($this->jailedPlayers[$playerName])) {
            if (isset($this->timeTasks[$playerName])) {
                $this->timeTasks[$playerName]->cancel();
                unset($this->timeTasks[$playerName]);
            }
            return;
        }

        $data = $this->jailedPlayers[$playerName];
        
        if ($data["totalTime"] > 0) {
            $now = time();
            $elapsed = $now - $data["lastUpdate"];
            $this->jailedPlayers[$playerName]["remainingTime"] = max(0, $data["remainingTime"] - $elapsed);
            $this->jailedPlayers[$playerName]["lastUpdate"] = $now;
            
            if ($this->jailedPlayers[$playerName]["remainingTime"] <= 0) {
                $this->unjailPlayer($playerName);
                return;
            }
            
            $time = gmdate("i:s", $this->jailedPlayers[$playerName]["remainingTime"]);
            $player->sendPopup("§cJail: §f{$time}");
        } else {
            $player->sendPopup("§cJail: §fUnlimited");
        }
    }

    private function unjailCommand(CommandSender $sender, array $args): bool {
        if (count($args) < 1) {
            if ($sender instanceof Player) {
                $this->showJailedList($sender);
                return true;
            }
            $sender->sendMessage(TextFormat::RED . "Usage: /unjail <player>");
            return true;
        }

        $targetName = $args[0];
        
        if (!isset($this->jailedPlayers[$targetName])) {
            $sender->sendMessage(TextFormat::RED . "Player is not jailed!");
            return true;
        }

        $this->unjailPlayer($targetName);
        $sender->sendMessage(TextFormat::GREEN . "Released {$targetName} from jail");
        
        $target = $this->getServer()->getPlayerByPrefix($targetName);
        if ($target instanceof Player) {
            $target->sendMessage($this->getConfig()->get("unjail-message", "§aYou have been released from jail!"));
        }
        
        return true;
    }

    private function showJailedList(Player $staff): void {
        $form = new SimpleForm(function(Player $staff, ?int $data) {
            if ($data === null) return;
            
            $jailed = array_keys($this->jailedPlayers);
            if (isset($jailed[$data])) {
                $this->unjailPlayer($jailed[$data]);
                $staff->sendMessage(TextFormat::GREEN . "Released {$jailed[$data]} from jail");
            }
        });

        $form->setTitle("Jailed Players");
        foreach (array_keys($this->jailedPlayers) as $name) {
            $form->addButton($name);
        }
        $staff->sendForm($form);
    }

    public function unjailPlayer(string $playerName): void {
        $player = $this->getServer()->getPlayerExact($playerName);
        
        if (isset($this->jailedPlayers[$playerName])) {
            $data = $this->jailedPlayers[$playerName];
            
            if ($player instanceof Player && $player->isOnline()) {
                $world = $this->getServer()->getWorldManager()->getWorldByName($data["pos"]["world"]);
                
                if ($world !== null) {
                    $pos = new Position(
                        $data["pos"]["x"],
                        $data["pos"]["y"],
                        $data["pos"]["z"],
                        $world
                    );
                    $player->teleport($pos);
                }
                
                $player->sendTitle("§aFreed!", "§7You have been released", 20, 60, 20);
                $player->sendMessage($this->getConfig()->get("unjail-message", "§aYou have been released from jail!"));
            }
            
            unset($this->jailedPlayers[$playerName]);
        }

        if (isset($this->timeTasks[$playerName])) {
            $this->timeTasks[$playerName]->cancel();
            unset($this->timeTasks[$playerName]);
        }

        if (isset($this->releaseTasks[$playerName])) {
            $this->releaseTasks[$playerName]->cancel();
            unset($this->releaseTasks[$playerName]);
        }
        
        $this->saveJailedPlayers();
    }

    private function scheduleRelease(string $playerName, int $duration): void {
        if (isset($this->releaseTasks[$playerName])) {
            $this->releaseTasks[$playerName]->cancel();
        }
        
        $task = new JailReleaseTask($this, $playerName);
        $this->releaseTasks[$playerName] = $this->getScheduler()->scheduleDelayedTask($task, $duration * 20);
    }

    private function setJailCommand(CommandSender $sender): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage(TextFormat::RED . "This command must be used in-game!");
            return true;
        }

        $this->jailPosition = $sender->getPosition();
        $this->getConfig()->set("jail-position", [
            "x" => $this->jailPosition->getX(),
            "y" => $this->jailPosition->getY(),
            "z" => $this->jailPosition->getZ(),
            "level" => $this->jailPosition->getWorld()->getFolderName()
        ]);
        $this->getConfig()->save();
        
        $sender->sendMessage(TextFormat::GREEN . "Jail location set!");
        return true;
    }

    private function jailListCommand(CommandSender $sender): bool {
        if (empty($this->jailedPlayers)) {
            $sender->sendMessage(TextFormat::GREEN . "No players are jailed!");
            return true;
        }

        $list = "§aJailed players:\n";
        foreach ($this->jailedPlayers as $name => $data) {
            if ($data["totalTime"] > 0) {
                $time = gmdate("i:s", $data["remainingTime"]);
            } else {
                $time = "Unlimited";
            }
            $status = $data["isOnline"] ? "§aOnline" : "§cOffline";
            $list .= "§7- §f{$name} §8(§e{$time}§8) §8[{$status}§8]\n";
        }
        $sender->sendMessage($list);
        return true;
    }

    private function jailStatusCommand(CommandSender $sender, array $args): bool {
        if (count($args) < 1) {
            $sender->sendMessage(TextFormat::RED . "Usage: /jailstatus <player>");
            return true;
        }

        $targetName = $args[0];
        if (!isset($this->jailedPlayers[$targetName])) {
            $sender->sendMessage(TextFormat::RED . "Player is not jailed!");
            return true;
        }

        $data = $this->jailedPlayers[$targetName];
        if ($data["totalTime"] > 0) {
            $time = gmdate("i:s", $data["remainingTime"]);
        } else {
            $time = "Unlimited";
        }
        $status = $data["isOnline"] ? "Online" : "Offline";
        $sender->sendMessage("§aJail status for {$targetName}: §e{$time} §8[§7{$status}§8]");
        return true;
    }

    public function onPlayerChat(PlayerChatEvent $event): void {
        $player = $event->getPlayer();
        if (isset($this->jailedPlayers[$player->getName()])) {
            $player->sendMessage(TextFormat::RED . "You can't chat while jailed!");
            $event->cancel();
        }
    }

    public function onPlayerCommand(CommandEvent $event): void {
        $player = $event->getSender();
        if (!$player instanceof Player) return;
        
        if (isset($this->jailedPlayers[$player->getName()])) {
            $cmd = strtolower(explode(" ", $event->getCommand())[0]);
            if (in_array($cmd, $this->blockedCmds)) {
                $player->sendMessage(TextFormat::RED . "You can't use this command while jailed!");
                $event->cancel();
            }
        }
    }

    public function onPlayerMove(PlayerMoveEvent $event): void {
        $player = $event->getPlayer();
        if (isset($this->jailedPlayers[$player->getName()]) && $this->jailPosition !== null) {
            $from = $event->getFrom();
            $to = $event->getTo();
            
            if ($from->distanceSquared($to) < 1) {
                return;
            }
            
            if ($player->getWorld() === $this->jailPosition->getWorld()) {
                $distance = $player->getPosition()->distance($this->jailPosition);
                if ($distance > $this->maxDistance) {
                    $player->teleport($this->jailPosition);
                    $player->sendMessage(TextFormat::RED . "You can't go further than {$this->maxDistance} blocks from jail!");
                }
            } else {
                $player->teleport($this->jailPosition);
                $player->sendMessage(TextFormat::RED . "You can't leave the jail world!");
            }
        }
    }

    public function onPlayerQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        $name = $player->getName();
        
        if (isset($this->jailedPlayers[$name])) {
            $this->jailedPlayers[$name]["isOnline"] = false;
            $this->saveJailedPlayers();
        }
        
        if (isset($this->timeTasks[$name])) {
            $this->timeTasks[$name]->cancel();
            unset($this->timeTasks[$name]);
        }
        
        if (isset($this->releaseTasks[$name])) {
            $this->releaseTasks[$name]->cancel();
            unset($this->releaseTasks[$name]);
        }
    }

    public function onPlayerJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $name = $player->getName();
        
        if (isset($this->jailedPlayers[$name])) {
            $this->jailedPlayers[$name]["isOnline"] = true;
            $this->jailedPlayers[$name]["lastUpdate"] = time();
            
            if ($this->jailPosition !== null) {
                $player->teleport($this->jailPosition);
                $player->sendTitle(
                    $this->getConfig()->get("welcome-message", "§cYou have been jailed!"),
                    $this->getConfig()->get("welcome-subtitle", "§7Follow the rules"),
                    20, 60, 20
                );
                $player->sendMessage($this->getConfig()->get("jail-message", "§cYou are still jailed!"));
            }
            
            $this->startJailTime($name);
            $this->saveJailedPlayers();
        }
    }

    public function onDisable(): void {
        $this->saveJailedPlayers();
        foreach ($this->timeTasks as $task) {
            $task->cancel();
        }
        foreach ($this->releaseTasks as $task) {
            $task->cancel();
        }
    }
}